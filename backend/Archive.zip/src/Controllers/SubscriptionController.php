<?php

namespace NfcAnycubic\Controllers;

use NfcAnycubic\Database;
use NfcAnycubic\AppleJWKHelper;
use NfcAnycubic\Middleware\AuthMiddleware;
use NfcAnycubic\Middleware\RateLimiter;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

/**
 * In-App Purchase Subscription Controller
 * Supports both Apple (iOS) and Google Play (Android)
 * StoreKit 2 compliant (2026 requirements)
 */
class SubscriptionController
{
    private $db;
    private $bundleId = 'com.engageengine.nfcfilament';
    private $androidPackageName = 'com.engagengine.nfc_anycubic';

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * POST /subscriptions/verify
     * Supports both iOS (JWS) and Android (purchaseToken)
     */
    public function verifyPurchase()
    {
        $userId = AuthMiddleware::getUserId();
        if (!$userId) return $this->error('Unauthorized', 401);

        // Rate limiting for purchase verification (sensitive endpoint)
        if (!RateLimiter::checkSensitive($userId)) {
            $this->logValidationFailure($userId, null, 'ios', 'rate_limited', 'Too many verification attempts');
            return $this->error('Too many requests. Please wait before retrying.', 429);
        }

        $data = json_decode(file_get_contents('php://input'), true);

        if (!isset($data['signedTransaction'])) {
            return $this->error('Missing signedTransaction', 400);
        }

        $signedTransaction = $data['signedTransaction'];
        $requestedProductId = $data['productId'] ?? null;
        $platform = $data['platform'] ?? 'ios';

        // Audit logging
        $this->logSubscriptionEvent($userId, null, 'verify_started', [
            'platform' => $platform,
            'product_id' => $requestedProductId
        ]);

        error_log("=== VERIFY PURCHASE ===");
        error_log("User: $userId | Platform: $platform | Product: $requestedProductId");

        try {
            if ($platform === 'android') {
                $result = $this->verifyGooglePlayPurchase($userId, $signedTransaction, $requestedProductId);
            } else {
                $result = $this->verifyApplePurchase($userId, $signedTransaction, $requestedProductId);
            }

            // Log success or failure
            if ($result['success'] ?? false) {
                $this->logSubscriptionEvent($userId, null, 'verify_success', [
                    'platform' => $platform,
                    'product_id' => $result['subscription']['product_id'] ?? $requestedProductId,
                    'is_premium' => $result['subscription']['is_premium'] ?? false
                ]);
            }

            return $result;

        } catch (\Exception $e) {
            error_log("Subscription verification error: " . $e->getMessage());
            $this->logValidationFailure($userId, null, $platform, 'unknown', $e->getMessage());
            return $this->error('Verification failed: ' . $e->getMessage(), 500);
        }
    }

    /**
     * Verify Apple (iOS) purchase
     */
    private function verifyApplePurchase($userId, $signedTransaction, $requestedProductId)
    {
        $transaction = $this->verifyAppleJWS($signedTransaction);

        if (!$transaction) {
            error_log("Transaction verification returned null");
            return $this->error('Invalid signature', 400);
        }

        if ($transaction->bundleId !== $this->bundleId) {
            error_log("Invalid bundle ID: " . $transaction->bundleId);
            return $this->error('Invalid bundle ID', 400);
        }

        // For Sandbox old receipt format, use the productId from the request
        if ($transaction->environment === 'Sandbox' && $requestedProductId) {
            $transaction->productId = $requestedProductId;
        }

        $validProducts = ['spool_master_monthly', 'spool_master_yearly'];
        if (!in_array($transaction->productId, $validProducts)) {
            error_log("Invalid product: " . $transaction->productId);
            return $this->error('Invalid product', 400);
        }

        $subscriptionId = $this->saveSubscription($userId, $transaction, $signedTransaction, 'ios');

        // Check if subscription is currently active
        if ($transaction->expiresDate === null) {
            error_log("⚠️ No expiration date available (PKCS#7 format) - accepting as active");
            $isActive = true;
            $expiresTimestamp = null;
        } else {
            $expiresTimestamp = $transaction->expiresDate / 1000;
            $isActive = $expiresTimestamp > time();
        }

        // Update user premium status based on expiration
        $this->updateUserPremiumStatus($userId, $isActive, $transaction->expiresDate);

        error_log("✅ iOS Subscription verified - Product: " . $transaction->productId);

        return [
            'success' => true,
            'subscription' => [
                'product_id' => $transaction->productId,
                'expires_at' => $transaction->expiresDate,
                'is_premium' => $isActive
            ]
        ];
    }

    /**
     * Verify Google Play (Android) purchase using Google Play Developer API
     * Best practices 2025-2026: Server-side verification is REQUIRED
     */
    private function verifyGooglePlayPurchase($userId, $purchaseToken, $productId)
    {
        error_log("🤖 Verifying Google Play purchase with API...");
        error_log("📦 Product ID: " . $productId);
        error_log("🎫 Purchase Token length: " . strlen($purchaseToken));

        $validProducts = ['spool_master_monthly', 'spool_master_yearly'];
        if (!in_array($productId, $validProducts)) {
            error_log("Invalid product: " . $productId);
            return $this->error('Invalid product', 400);
        }

        // Check if service account is configured
        $serviceAccountPath = __DIR__ . '/../../config/google-play-service-account.json';

        if (!file_exists($serviceAccountPath)) {
            error_log("⚠️ Service account not configured - using fallback verification");
            return $this->verifyGooglePlayPurchaseFallback($userId, $purchaseToken, $productId);
        }

        try {
            $serviceAccount = json_decode(file_get_contents($serviceAccountPath), true);
            if (!$serviceAccount || !isset($serviceAccount['client_email']) || !isset($serviceAccount['private_key'])) {
                error_log("❌ Invalid service account file format");
                return $this->verifyGooglePlayPurchaseFallback($userId, $purchaseToken, $productId);
            }

            // Get OAuth2 access token
            $accessToken = $this->getGoogleAccessToken($serviceAccount);
            if (!$accessToken) {
                error_log("❌ Failed to get Google access token");
                return $this->verifyGooglePlayPurchaseFallback($userId, $purchaseToken, $productId);
            }

            // Call Google Play Developer API to verify subscription
            $url = "https://androidpublisher.googleapis.com/androidpublisher/v3/applications/{$this->androidPackageName}/purchases/subscriptions/{$productId}/tokens/{$purchaseToken}";

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Authorization: Bearer ' . $accessToken,
                'Content-Type: application/json'
            ]);
            curl_setopt($ch, CURLOPT_TIMEOUT, 30);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = curl_error($ch);
            curl_close($ch);

            if ($curlError) {
                error_log("❌ cURL error: " . $curlError);
                return $this->verifyGooglePlayPurchaseFallback($userId, $purchaseToken, $productId);
            }

            error_log("📡 Google Play API response code: " . $httpCode);

            if ($httpCode !== 200) {
                error_log("❌ Google Play API error: $httpCode - $response");
                // Don't accept invalid purchases
                return $this->error('Purchase verification failed', 400);
            }

            $purchaseData = json_decode($response);
            error_log("📦 Google Play response: " . json_encode($purchaseData));

            // Verify the subscription data
            if (!isset($purchaseData->expiryTimeMillis)) {
                error_log("❌ No expiry time in Google Play response");
                return $this->error('Invalid subscription data', 400);
            }

            $expiresDate = (int)$purchaseData->expiryTimeMillis;
            $isActive = $expiresDate > (time() * 1000);

            // Log subscription details
            error_log("📅 Expiry: " . date('Y-m-d H:i:s', $expiresDate / 1000));
            error_log("💳 Payment state: " . ($purchaseData->paymentState ?? 'N/A'));
            error_log("✅ Is active: " . ($isActive ? 'YES' : 'NO'));

            $transaction = (object)[
                'productId' => $productId,
                'originalTransactionId' => 'gp_' . substr(md5($purchaseToken), 0, 16),
                'transactionId' => $purchaseData->orderId ?? ('gp_' . time()),
                'purchaseDate' => $purchaseData->startTimeMillis ?? (time() * 1000),
                'expiresDate' => $expiresDate,
                'environment' => 'Production',
                'bundleId' => $this->androidPackageName
            ];

            $this->saveSubscription($userId, $transaction, $purchaseToken, 'android');
            $this->updateUserPremiumStatus($userId, $isActive, $expiresDate);

            error_log("✅ Google Play subscription verified via API - Active: " . ($isActive ? 'yes' : 'no'));

            return [
                'success' => true,
                'subscription' => [
                    'product_id' => $productId,
                    'expires_at' => $expiresDate,
                    'is_premium' => $isActive
                ]
            ];

        } catch (\Exception $e) {
            error_log("❌ Google Play verification exception: " . $e->getMessage());
            return $this->error('Verification failed: ' . $e->getMessage(), 500);
        }
    }

    /**
     * Handle missing Google Play service account configuration
     * SECURITY: No longer accepts purchases without proper verification
     */
    private function verifyGooglePlayPurchaseFallback($userId, $purchaseToken, $productId)
    {
        error_log("❌ REJECTED: Google Play service account not configured");
        error_log("❌ Configure backend/config/google-play-service-account.json to enable verification");
        error_log("❌ See: https://developers.google.com/android-publisher/getting_started");

        // SECURITY: Do NOT accept unverified purchases
        // This prevents fraud when service account is not configured
        return $this->error(
            'Google Play verification unavailable. Please contact support or try again later.',
            503 // Service Unavailable
        );
    }

    /**
     * Get OAuth2 access token for Google Play Developer API
     */
    private function getGoogleAccessToken($serviceAccount)
    {
        try {
            $now = time();
            $jwt = [
                'iss' => $serviceAccount['client_email'],
                'scope' => 'https://www.googleapis.com/auth/androidpublisher',
                'aud' => 'https://oauth2.googleapis.com/token',
                'iat' => $now,
                'exp' => $now + 3600
            ];

            $privateKey = $serviceAccount['private_key'];
            $token = JWT::encode($jwt, $privateKey, 'RS256');

            $ch = curl_init('https://oauth2.googleapis.com/token');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
                'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                'assertion' => $token
            ]));
            curl_setopt($ch, CURLOPT_TIMEOUT, 30);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode !== 200) {
                error_log("❌ Google OAuth token request failed: $httpCode - $response");
                return null;
            }

            $data = json_decode($response, true);

            if (isset($data['access_token'])) {
                error_log("✅ Got Google access token (expires in " . ($data['expires_in'] ?? '?') . "s)");
                return $data['access_token'];
            }

            error_log("❌ No access_token in Google OAuth response");
            return null;

        } catch (\Exception $e) {
            error_log("❌ Google OAuth exception: " . $e->getMessage());
            return null;
        }
    }

    /**
     * GET /subscriptions/status
     */
    public function getSubscriptionStatus()
    {
        $userId = AuthMiddleware::getUserId();
        if (!$userId) return $this->error('Unauthorized', 401);

        try {
            // Check for active subscriptions (expires_date > NOW() OR expires_date IS NULL for Sandbox PKCS#7)
            $stmt = $this->db->prepare("
                SELECT product_id, status, expires_date, auto_renew_enabled, environment
                FROM subscriptions
                WHERE user_id = ?
                    AND status IN ('active', 'grace_period')
                    AND (expires_date > NOW() OR expires_date IS NULL)
                ORDER BY expires_date DESC
                LIMIT 1
            ");
            $stmt->execute([$userId]);
            $subscription = $stmt->fetch(\PDO::FETCH_ASSOC);

            $isPremium = $subscription !== false;

            error_log("📊 getSubscriptionStatus for user $userId: isPremium=$isPremium");

            return [
                'success' => true,
                'is_premium' => $isPremium,
                'subscription' => $subscription ?: null
            ];

        } catch (\Exception $e) {
            error_log("Error fetching subscription status: " . $e->getMessage());
            return $this->error('Server error: ' . $e->getMessage(), 500);
        }
    }

    /**
     * POST /subscriptions/webhook
     */
    public function handleAppleWebhook()
    {
        return ['success' => true, 'message' => 'Webhook received'];
    }

    /**
     * GET /cron/check-expired/:secret
     * Endpoint public CRON avec secret pour vérifier les expirations
     */
    public function cronCheckExpired($params)
    {
        // Extract secret from route parameters
        $secret = $params['secret'] ?? null;

        // Load secret from environment (not hardcoded)
        $config = require __DIR__ . '/../../config/app.php';
        $validSecret = $config['cron_secret'] ?? '';

        if (empty($validSecret)) {
            error_log("❌ CRON_SECRET not configured in environment");
            http_response_code(503);
            return ['success' => false, 'error' => 'CRON not configured'];
        }

        // Use timing-safe comparison to prevent timing attacks
        if (!hash_equals($validSecret, $secret ?? '')) {
            error_log("❌ Invalid CRON secret attempt from IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
            http_response_code(403);
            return ['success' => false, 'error' => 'Invalid secret'];
        }

        return $this->checkExpiredSubscriptions();
    }

    /**
     * POST /subscriptions/check-expired
     * Vérifie et marque les abonnements expirés (peut être appelé manuellement)
     */
    public function checkExpiredSubscriptions()
    {
        try {
            error_log("🕐 [MANUAL] Starting subscription expiration check...");

            // 1. Mettre à jour les abonnements expirés
            $stmt = $this->db->prepare("
                UPDATE subscriptions
                SET status = 'expired',
                    updated_at = CURRENT_TIMESTAMP
                WHERE status = 'active'
                  AND expires_date IS NOT NULL
                  AND expires_date < NOW()
            ");

            $stmt->execute();
            $expiredCount = $stmt->rowCount();

            // 2. Désactiver le premium pour les utilisateurs
            $stmt = $this->db->prepare("
                UPDATE user_preferences up
                SET is_vip = 0,
                    vip_expires_at = NULL
                WHERE up.is_vip = 1
                  AND NOT EXISTS (
                      SELECT 1
                      FROM subscriptions s
                      WHERE s.user_id = up.user_id
                        AND s.status = 'active'
                        AND (s.expires_date IS NULL OR s.expires_date > NOW())
                  )
            ");

            $stmt->execute();
            $deactivatedCount = $stmt->rowCount();

            error_log("✅ [MANUAL] Expiration check completed - Expired: $expiredCount, Deactivated: $deactivatedCount");

            return [
                'success' => true,
                'expired_count' => $expiredCount,
                'deactivated_count' => $deactivatedCount,
                'message' => "Checked subscriptions: $expiredCount expired, $deactivatedCount users deactivated"
            ];

        } catch (\Exception $e) {
            error_log("❌ [MANUAL] Error: " . $e->getMessage());
            return $this->error('Failed to check expired subscriptions: ' . $e->getMessage(), 500);
        }
    }

    private function verifyAppleJWS($jws)
    {
        try {
            // SECURITY: Reject old PKCS#7 receipt format (StoreKit 1)
            // As of 2026, Apple requires StoreKit 2 (JWS format) for all apps
            // PKCS#7 format starts with "MI" (base64 for ASN.1 SEQUENCE)
            if (substr($jws, 0, 2) === 'MI' && strlen($jws) > 5000) {
                error_log("❌ REJECTED: Old PKCS#7 receipt format (StoreKit 1)");
                error_log("❌ StoreKit 2 (JWS format) is required as of 2026");
                error_log("❌ Please update your app to use StoreKit 2");

                // Do NOT accept - require proper JWS verification
                return null;
            }

            // Standard StoreKit 2 JWS verification
            error_log("🔐 Validating StoreKit 2 JWS token...");

            $parts = explode('.', $jws);
            if (count($parts) !== 3) {
                error_log("❌ Invalid JWS format - expected 3 parts, got " . count($parts));
                return null;
            }

            // Decode header to get certificate chain (x5c)
            $header = json_decode(base64_decode(strtr($parts[0], '-_', '+/')));
            if (!$header) {
                error_log("❌ Failed to decode JWS header");
                return null;
            }

            error_log("📋 JWS Header algorithm: " . ($header->alg ?? 'unknown'));

            // Extract public key from x5c certificates (like Motoro does)
            if (!isset($header->x5c) || !is_array($header->x5c) || count($header->x5c) === 0) {
                error_log("❌ No x5c certificates found in JWS header");
                return null;
            }

            // The first certificate in x5c is the one used to sign the JWS
            $cert = $header->x5c[0];
            $certPem = "-----BEGIN CERTIFICATE-----\n" . $cert . "\n-----END CERTIFICATE-----";

            // Extract public key from certificate
            $publicKeyResource = openssl_pkey_get_public($certPem);
            if (!$publicKeyResource) {
                error_log("❌ Failed to extract public key from certificate");
                return null;
            }

            $publicKeyDetails = openssl_pkey_get_details($publicKeyResource);
            $publicKey = $publicKeyDetails['key'];

            // Verify signature using the public key
            $decoded = JWT::decode($jws, new Key($publicKey, 'ES256'));

            if (!$decoded) {
                error_log("❌ JWT decode failed");
                return null;
            }

            error_log("✅ JWS signature valid");

            // Log payload information for debugging
            error_log("📦 Transaction ID: " . ($decoded->transactionId ?? 'N/A'));
            error_log("📦 Product ID: " . ($decoded->productId ?? 'N/A'));
            error_log("📦 Bundle ID: " . ($decoded->bundleId ?? 'N/A'));
            error_log("📦 Environment: " . ($decoded->environment ?? 'N/A'));

            if (isset($decoded->purchaseDate)) {
                error_log("📅 Purchase Date: " . date('Y-m-d H:i:s', $decoded->purchaseDate / 1000));
            }

            if (isset($decoded->expiresDate)) {
                error_log("📅 Expires Date: " . date('Y-m-d H:i:s', $decoded->expiresDate / 1000));
            } else {
                error_log("⚠️ No expiresDate in payload");
            }

            return $decoded;

        } catch (\Exception $e) {
            error_log("❌ JWS verification failed: " . $e->getMessage());
            error_log("Stack trace: " . $e->getTraceAsString());
            return null;
        }
    }

    private function getApplePublicKey($kid)
    {
        $cacheFile = __DIR__ . '/../../cache/apple_jwks.json';
        $cacheDir = dirname($cacheFile);

        if (!is_dir($cacheDir)) {
            mkdir($cacheDir, 0755, true);
        }

        return AppleJWKHelper::getApplePublicKeyPem($kid, $cacheFile);
    }

    private function saveSubscription($userId, $transaction, $signedTransaction, $platform = 'ios')
    {
        // Check if subscription already exists
        $checkStmt = $this->db->prepare("
            SELECT id, expires_date, status
            FROM subscriptions
            WHERE user_id = ? AND original_transaction_id = ?
        ");
        $checkStmt->execute([$userId, $transaction->originalTransactionId]);
        $existing = $checkStmt->fetch(\PDO::FETCH_ASSOC);

        $purchaseDate = $transaction->purchaseDate / 1000;
        $expiresDate = $transaction->expiresDate ? ($transaction->expiresDate / 1000) : null;
        $environment = $transaction->environment ?? 'Production';

        // Determine status based on expiration date
        $now = time();
        if ($expiresDate === null) {
            // PKCS#7 Sandbox - cannot determine expiration, assume active
            $status = 'active';
        } else {
            $status = ($expiresDate > $now) ? 'active' : 'expired';
        }

        error_log("💾 Saving subscription - Platform: $platform, Status: $status, Expires: " . ($expiresDate ? date('Y-m-d H:i:s', $expiresDate) : 'N/A'));

        if ($existing) {
            // Update existing subscription with Apple's data
            error_log("🔄 Updating existing subscription ID: " . $existing['id']);

            if ($expiresDate !== null) {
                $stmt = $this->db->prepare("
                    UPDATE subscriptions
                    SET transaction_id = ?,
                        status = ?,
                        purchase_date = FROM_UNIXTIME(?),
                        expires_date = FROM_UNIXTIME(?),
                        environment = ?,
                        jws_transaction = ?,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                ");

                $stmt->execute([
                    $transaction->transactionId,
                    $status,
                    $purchaseDate,
                    $expiresDate,
                    $environment,
                    $signedTransaction,
                    $existing['id']
                ]);
            } else {
                // No expires date (PKCS#7) - skip updating it
                $stmt = $this->db->prepare("
                    UPDATE subscriptions
                    SET transaction_id = ?,
                        status = ?,
                        purchase_date = FROM_UNIXTIME(?),
                        environment = ?,
                        jws_transaction = ?,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                ");

                $stmt->execute([
                    $transaction->transactionId,
                    $status,
                    $purchaseDate,
                    $environment,
                    $signedTransaction,
                    $existing['id']
                ]);
            }

            return $existing['id'];
        } else {
            // Insert new subscription
            error_log("➕ Creating new subscription");

            if ($expiresDate !== null) {
                $stmt = $this->db->prepare("
                    INSERT INTO subscriptions (
                        user_id, original_transaction_id, transaction_id, product_id,
                        status, purchase_date, expires_date, environment, jws_transaction
                    ) VALUES (?, ?, ?, ?, ?, FROM_UNIXTIME(?), FROM_UNIXTIME(?), ?, ?)
                ");

                $stmt->execute([
                    $userId,
                    $transaction->originalTransactionId,
                    $transaction->transactionId,
                    $transaction->productId,
                    $status,
                    $purchaseDate,
                    $expiresDate,
                    $environment,
                    $signedTransaction
                ]);
            } else {
                // No expires date (PKCS#7) - set to NULL
                $stmt = $this->db->prepare("
                    INSERT INTO subscriptions (
                        user_id, original_transaction_id, transaction_id, product_id,
                        status, purchase_date, expires_date, environment, jws_transaction
                    ) VALUES (?, ?, ?, ?, ?, FROM_UNIXTIME(?), NULL, ?, ?)
                ");

                $stmt->execute([
                    $userId,
                    $transaction->originalTransactionId,
                    $transaction->transactionId,
                    $transaction->productId,
                    $status,
                    $purchaseDate,
                    $environment,
                    $signedTransaction
                ]);
            }

            return $this->db->lastInsertId();
        }
    }

    private function updateUserPremiumStatus($userId, $isPremium, $expiresDate = null)
    {
        $expiresTimestamp = $expiresDate ? date('Y-m-d H:i:s', $expiresDate / 1000) : null;

        $stmt = $this->db->prepare("
            INSERT INTO user_preferences (user_id, is_vip, vip_expires_at)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE
                is_vip = VALUES(is_vip),
                vip_expires_at = VALUES(vip_expires_at)
        ");

        $stmt->execute([$userId, $isPremium ? 1 : 0, $expiresTimestamp]);
    }

    private function error($message, $code = 400)
    {
        http_response_code($code);
        return ['success' => false, 'error' => $message];
    }

    /**
     * Log subscription event for audit trail
     */
    private function logSubscriptionEvent(
        ?string $userId,
        ?string $originalTransactionId,
        string $eventType,
        array $eventData = [],
        string $source = 'api'
    ): void {
        try {
            // Get subscription ID if we have transaction ID
            $subscriptionId = null;
            if ($originalTransactionId) {
                $stmt = $this->db->prepare(
                    "SELECT id FROM subscriptions WHERE original_transaction_id = ?"
                );
                $stmt->execute([$originalTransactionId]);
                $row = $stmt->fetch();
                $subscriptionId = $row['id'] ?? null;
            }

            $stmt = $this->db->prepare("
                INSERT INTO subscription_events
                (subscription_id, user_id, original_transaction_id, event_type, event_data, source, ip_address, user_agent)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $subscriptionId,
                $userId,
                $originalTransactionId,
                $eventType,
                json_encode($eventData),
                $source,
                $_SERVER['REMOTE_ADDR'] ?? null,
                substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500)
            ]);
        } catch (\Exception $e) {
            // Don't fail the main operation if logging fails
            error_log("Failed to log subscription event: " . $e->getMessage());
        }
    }

    /**
     * Log validation failure for security monitoring
     */
    private function logValidationFailure(
        ?string $userId,
        ?string $transactionId,
        string $platform,
        string $reason,
        ?string $errorMessage = null,
        ?string $jwsPayload = null
    ): void {
        try {
            // Map reason to enum value
            $validReasons = [
                'invalid_signature', 'expired_transaction', 'invalid_bundle_id',
                'replay_attack', 'invalid_product', 'certificate_error',
                'network_error', 'rate_limited', 'unknown'
            ];
            $reason = in_array($reason, $validReasons) ? $reason : 'unknown';

            $stmt = $this->db->prepare("
                INSERT INTO subscription_validation_failures
                (user_id, transaction_id, platform, failure_reason, error_message, jws_payload, ip_address, user_agent)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $userId,
                $transactionId,
                $platform,
                $reason,
                $errorMessage,
                $jwsPayload ? substr($jwsPayload, 0, 10000) : null, // Limit size
                $_SERVER['REMOTE_ADDR'] ?? null,
                substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500)
            ]);

            error_log("Validation failure logged: $reason for user $userId");
        } catch (\Exception $e) {
            error_log("Failed to log validation failure: " . $e->getMessage());
        }
    }

    /**
     * Check for replay attack (duplicate transaction)
     */
    private function checkReplayAttack(string $transactionId, string $userId): bool
    {
        // Check if this transaction was processed in the last hour
        $stmt = $this->db->prepare("
            SELECT id FROM subscriptions
            WHERE transaction_id = ?
            AND user_id = ?
            AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)
        ");
        $stmt->execute([$transactionId, $userId]);

        if ($stmt->fetch()) {
            $this->logValidationFailure($userId, $transactionId, 'ios', 'replay_attack', 'Duplicate transaction in 1 hour');
            return true;
        }

        return false;
    }
}
